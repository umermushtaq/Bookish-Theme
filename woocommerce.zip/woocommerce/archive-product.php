<?php 
	/*
	 * This file is used to generate WordPress standard archive/category pages.
	 */	
get_header(); ?>
<?php
	    global $paged, $crunchpress_sidebar, $left_sidebar, $right_sidebar;
		$left_sidebar = "Shop Left Sidebar";
		$right_sidebar = "Shop Right Sidebar";
			
		$crunchpress_sidebar = get_option ( THEME_NAME_S . '_products_page_sidebar', 'no-sidebar' );
        $crunchpress_sidebar = str_replace('product-', '', $crunchpress_sidebar) ; 
		
		    $sidebar_class = '';
        if ($crunchpress_sidebar == "left-sidebar" || $crunchpress_sidebar == "right-sidebar") {
            $sidebar_class = "sidebar-included " . $crunchpress_sidebar;
			$container_class = "span8";
        } else if ($sicrunchpress_sidebardebar == "both-sidebar") {
            $sidebar_class = "both-sidebar-included";
			 $bcontainer_class ="span9";
			 $container_class = "span6";
        } else {
		    $container_class = "span12";	
		}
		
	?>
            
		
  <?php
							
					
					echo '<div class="content">';
					echo '<section id="inner-page-holder">';
					
					echo '<div class="container">';
					echo '<div class="row">';
                   											
							//get_sidebar ( 'left' );
							
								if ($crunchpress_sidebar == "left-sidebar") {
									$float_class = 'class="floater-right"';
								} else if ($crunchpress_sidebar == "right-sidebar") {
									$float_class = 'class="floater-left"';
								} else if ($crunchpress_sidebar == "both-sidebar") {
									$float_class = 'class="floater-none"';
								}
								
								echo '<div '. $float_class .'>';
						   ?>
                           <section id="title-bar" class="content-col">
                              <section class="container-fluid container">
                                <section class="row-fluid">
                                  <article class="span8">
                                    <h2>
                                    <?php if ( is_search() ) : printf( __( 'Search Results: &ldquo;%s&rdquo;', 'woocommerce' ), get_search_query() );
                                          if ( get_query_var( 'paged' ) ) printf( __( '&nbsp;&ndash; Page %s', 'woocommerce' ), get_query_var( 'paged' ) );
                                        ?>
                                    <?php elseif ( is_tax() ) : 
                                          echo single_term_title( "", false ); 
                                          else :
                                          $shop_page = get_post( woocommerce_get_page_id( 'shop' ) );
                                          echo apply_filters( 'the_title', ( $shop_page_title = get_option( 'woocommerce_shop_page_title' ) ) ? $shop_page_title : $shop_page->post_title );
                                          endif; 
                                     ?>
                                    
                                    </h2>
                                    <p><span>You are here:</span> <?php if ( function_exists( 'cp_breadcrumbs' ) ) { cp_breadcrumbs(); } ?></p>
                                  </article>
                                  <?php if ( function_exists( 'print_social' ) ) { print_social(); } ?>
                                </section>
                              </section>
                           </section>
                        
                                <?php do_action( 'woocommerce_archive_description' ); ?>
                        
                                <?php if ( is_tax() ) : ?>
                                    <?php do_action( 'woocommerce_taxonomy_archive_description' ); ?>
                                <?php elseif ( ! empty( $shop_page ) && is_object( $shop_page ) ) : ?>
                                    <?php do_action( 'woocommerce_product_archive_description', $shop_page ); ?>
                                <?php endif; ?>

                    		<?php 
						// start fetching database
						global $post, $wp_query;
							
						$port_size ="element1-4" ;
						$paged = (get_query_var('page')) ? get_query_var('page') : 1; 
						
	                   	//echo ' <section class="grid-holder features-books">';
							
						
						
						if( $sidebar == "product-no-sidebar"){
						/*woocommerce_catalog_ordering();*/
						}
								
							// get the category for filter
							$item_categories = get_the_terms( $post->ID, 'product_cat' );
							$category_slug = " ";
							if( !empty($item_categories) ){
								foreach( $item_categories as $item_category ){
									$category_slug = $category_slug . $item_category->slug . ' ';
								}
							}
							
							?>
							
							
                            <?php 
									if( function_exists('woocommerce_get_template_part')) {
		
									$item_size_new = '276x197';
							
									// start fetching database
									global $post, $wp_query;
									echo '<div class="'. $container_class .'">';
							?>			
												<section class="product-detail">
													<div class="row-fluid">
														<div class="container">
															<div class="product-list-tab">
                                                            
                                                            <?php
															echo '<div class="product-list-pagination">';
															if( find_xml_value($item_xml, "pagination") == "Yes" ){	
																product_pagination();
															}
															echo '</div>';
														echo '<ul class="nav nav-tabs list-tab-nav" id="myTab">';
															echo '<li><strong class="items">Item(s)</strong></li>';
															echo '<li><a href="#tab-01" class="tab-01"><span class="grid"></span>Grid</a></li>';
															echo '<li><a href="#tab-02" class="tab-02"><span class="list"></span>List</a></li>';
															echo '<li class="pull-right">';
															do_action('woocommerce_before_shop_loop'); 
															echo '</li>';
														echo '</ul>';
												
												
												
												echo '<div class="tab-content list-content">';
												
												/* Product Grid View */
												?>
												
												 <div class="tab-pane active" id="tab-01">
													<?php
                                                    
													echo '<div class="product-grid-outer">';
													  echo '<div class="product-grid">';
														echo '<div class="row-fluid">';
														  echo '<div class="container">';
														 
														 global $product;
														 
														 while( have_posts() ){
															the_post();	
															
															// get the category for filter
															$item_categories = get_the_terms( $post->ID, 'product_cat' );
															$category_slug = " ";
															if( !empty($item_categories) ){
																foreach( $item_categories as $item_category ){
																	$category_slug = $category_slug . $item_category->slug . ' ';
																}
															
																	// start printing data
																	$item_size_new = '270x224';
																	$thumbnail_types = "Image";
																	if( $thumbnail_types == "Image" ){
																		$image_type = "Lightbox to Current Thumbnail";
																		$image_type = empty($image_type)? "Link to Current Post": $image_type; 
																		$thumbnail_id = get_post_thumbnail_id();
																		$thumbnail = wp_get_attachment_image_src( $thumbnail_id , $item_size_new );
																		$alt_text = get_post_meta($thumbnail_id , '_wp_attachment_image_alt', true);
																		$image_type ="Lightbox to Picture";
																		if($image_type == "Lightbox to Picture" ){
																			$hover_thumb = "hover-link";
																			$permalink = get_permalink();	
																			
																		}		
																	}
																	$product_title= get_the_title();
																	$title_length = get_option(THEME_NAME_S.'_products_page_title_length');					 
																	$short_title = substr($product_title,0,$title_length);
																	$product_short_description = substr(get_the_excerpt(),0,'200');
																	$product_detail_link = get_permalink();
														 
															echo '<div class="span3 slide">';
															  echo '<div class="product-grid-box">';
															  echo '<div class="b-img-holder">';
																echo '<div class="frame"><a href="' . $permalink . '">';
																	echo '<img  src="' . $thumbnail[0] .'" alt="'. $alt_text .'"/>';
																echo'</a>';
																//woocommerce_show_product_loop_sale_flash();
																//do_action( 'woocommerce_show_product_loop_sale_flash');
																//do_action( 'woocommerce_before_shop_loop_item' );
																echo '</div>';
																echo '</div>';
																echo'<div class="product-grid-text"> <strong class="name">';
																//echo $product->get_categories( ', ', '' . _n( '', '', sizeof( get_the_terms( $post->ID, 'product_cat' ) ), 'woocommerce' ) . ' ', '.' );
																echo '</strong>';
																  echo'<div class="star-box pull-right"><img src="'. CP_PATH_URL .'/assets/images/star-img.png" alt="img"></div>';
																  echo'<a href="'. $product_detail_link .'"><strong class="title">' . $product_title. '</strong></a>';
																  echo'<p>'. $product_short_description .'</p>';
																  echo'<strong class="price">';
																  	do_action( 'woocommerce_after_shop_loop_item_title' );
																  echo '</strong>';
																  /* <a href="#" class="btn-cart">Add to Cart</a> <a href="#" class="btn-view">View Cart</a>*/
																  do_action( 'woocommerce_after_shop_loop_item' );
																  echo '</div>';
															  echo'</div>';
															echo'</div>';
														  					
														 
												  }
												}
												echo '</div>
														</div>
													  </div>
													</div>';
													
													?>
												  </div>
												
												<?php
												/* Product List View */
												?>
                                                
												 <div class="tab-pane" id="tab-02">
												<?php
                                                
												echo '<div class="row-fluid">
													  <div class="container">
														<div class="list-content">
														  <ul>';
														  
														  global $product;
														  
														  while( have_posts() ){
															the_post();				
																			
															// get the category for filter
															$item_categories = get_the_terms( $post->ID, 'product_cat' );
															$category_slug = " ";
															if( !empty($item_categories) ){
																foreach( $item_categories as $item_category ){
																	$category_slug = $category_slug . $item_category->slug . ' ';
																}
															
																	// start printing data
																	$item_size_new = '270x224';
																	$thumbnail_types = "Image";
																	if( $thumbnail_types == "Image" ){
																		$image_type = "Lightbox to Current Thumbnail";
																		$image_type = empty($image_type)? "Link to Current Post": $image_type; 
																		$thumbnail_id = get_post_thumbnail_id();
																		$thumbnail = wp_get_attachment_image_src( $thumbnail_id , $item_size_new );
																		$alt_text = get_post_meta($thumbnail_id , '_wp_attachment_image_alt', true);
																		$image_type ="Lightbox to Picture";
																		if($image_type == "Lightbox to Picture" ){
																			$hover_thumb = "hover-link";
																			$permalink = get_permalink();	
																			
																		}		
																	}
																	$product_title= get_the_title();
																	$product_short_description = substr(get_the_excerpt(),0,'590');
																	$title_length = get_option(THEME_NAME_S.'_products_page_title_length');					 
																	$short_title = substr($product_title,0,$title_length);
																	$product_detail_link = get_permalink();
															
															echo '<li>';
															  echo '<div class="span3">';
															  echo '<div class="b-img-holder">';
																echo '<div class="frame">';
																	echo '<a href="' . $permalink . '">';
																		echo '<img  src="' . $thumbnail[0] .'" alt="'. $alt_text .'"/>';
																	echo '</a>'; 
																
															echo '</div>';
															echo '</div>';
															  echo '</div>';
															  echo '<div class="span9">';
																echo '<div class="list-text">';
																  echo '<a href="'. $product_detail_link .'"><h2>' . $product_title. '</h2></a>';
																  echo '<strong class="title">Category : &nbsp;';
																  echo $product->get_categories( ', ', '' . _n( '', '', sizeof( get_the_terms( $post->ID, 'product_cat' ) ), 'woocommerce' ) . ' ', '.' );
																  echo '</strong>';
																  echo '<strong class="price">';
																  do_action( 'woocommerce_after_shop_loop_item_title' );
																  echo '</strong>';
																  echo '<div class="star-box"><img src="'. CP_PATH_URL .'/assets/images/star-img.png" alt="img"></div>';
																  echo '<p>'. $product_short_description .'</p>';
																  //<a href="#" class="btn-cart">Add to Cart</a> <a href="#" class="btn-view">View Cart</a> 
																//woocommerce_show_product_loop_sale_flash();
																//do_action( 'woocommerce_show_product_loop_sale_flash');
																//do_action( 'woocommerce_before_shop_loop_item' );
																do_action( 'woocommerce_after_shop_loop_item' );
																  echo '</div>';
															  echo '</div>';
															echo '</li>';
														 }
														}	
														
													echo '	  </ul>
														</div>
													  </div>
													</div>';
													
													?>
												  </div>
												<?php
												
							
												} else{ 
													   echo'<div class="message-box-wrapper red mr10">';
													   echo'<div class="message-box-title">Missing Woo Commerce Plugin</div>';
													   echo'<div class="message-box-content">Please install Woo Commerce Plugin</div>';
													   echo'</div>';
													  } 

										?>
                                     
                                  </div>
                                </div>
                              </div>
                            </section>
                            <?php
                           
		                			//get_sidebar ( 'right' );
									echo '</div>';
							?>
            
            			</div>
            		</div>
            	</div>
            
     	</section>
<!--content-separator-->
<?php get_footer(); ?>
