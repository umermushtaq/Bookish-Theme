<?php

/**

 * The Template for displaying all single products.

 *

 * Override this template by copying it to yourtheme/woocommerce/single-product.php

 *

 * @author 		WooThemes

 * @package 	WooCommerce/Templates

 * @version     1.6.4

 */



if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



get_header('shop'); ?>



	<?php

		/**

		 * woocommerce_before_main_content hook

		 *

		 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)

		 * @hooked woocommerce_breadcrumb - 20

		 */

		do_action('woocommerce_before_main_content');



	?>



	   

        

               

                <!--Product Detail Page Start-->

                <section class="product-detail">

                  <div class="row-fluid">

                    <div class="container">

						<div class="product-cart-area">

										<?php  while ( have_posts() ) : the_post(); ?>

                                

                                        <?php woocommerce_get_template_part( 'content', 'single-product' ); ?>

                                

                                        <?php endwhile; // end of the loop. ?>

                                

                                       

                                    

                                        <?php
                                            /**
                                             * woocommerce_sidebar hook
                                             *
                                             * @hooked woocommerce_get_sidebar - 10
                                             */
											 
                                            do_action('woocommerce_sidebar');

                                        ?>
                                        
                        </div>

                        <div class="related-products">

                                <h2><?php echo 'Related Products'; ?></h2>

                                <?php
								
									 global $product;
									 
									 $args = array(
													'post_type' => 'product',
													'no_found_rows' => 1,
													'posts_per_page' => 4,
													'ignore_sticky_posts' => 1,
													'orderby' => $orderby,
													'post__in' => $related,
													'post__not_in' => array($product->id)
													);

									
									query_posts( $args );

									while (have_posts()){ the_post();

									// start printing data

									$item_size_new = '270x224';

									$thumbnail_types = "Image";

									if( $thumbnail_types == "Image" ){

										$image_type = "Lightbox to Current Thumbnail";

										$image_type = empty($image_type)? "Link to Current Post": $image_type; 

										$thumbnail_id = get_post_thumbnail_id();

										$thumbnail = wp_get_attachment_image_src( $thumbnail_id , $item_size_new );

										$alt_text = get_post_meta($thumbnail_id , '_wp_attachment_image_alt', true);

										$image_type ="Lightbox to Picture";

										if($image_type == "Lightbox to Picture" ){

											$hover_thumb = "hover-link";

											$permalink = get_permalink();	

											

										}		

									}

									$product_title= get_the_title();

									$title_length = get_option(THEME_NAME_S.'_products_page_title_length');					 

									$short_title = substr($product_title,0,$title_length);

									$product_short_description = substr(get_the_excerpt(),0,'150');

                                

                                	echo '<div class="frame"><a href="' . $permalink . '">';

									echo '<img  src="' . $thumbnail[0] .'" alt="'. $alt_text .'"/>';

									echo'</a>';

                                  	echo'<div class="caption"> <strong class="title">' . $product_title. '</strong> <strong class="price">';

									do_action( 'woocommerce_after_shop_loop_item_title' );

									echo '</strong>';

                                    //echo'<p>'. $product_short_description .'</p>';

                                  	echo'</div>';

                                	echo'</div>';

                             

									}

								?>

                      </div>
                                      
					</div>
                    
                  </div>
                  
                </section>
                     
              <div style="clear:both; margin:0; padding:0;"></div>

              					<?php

										/**

										 * woocommerce_after_main_content hook

										 *

										 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)

										 */

										 do_action('woocommerce_after_main_content');

                                ?>

                      

        

<?php get_footer(); ?>