<?php
/**
 * Single Product tabs
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

// Get tabs
ob_start();

do_action('woocommerce_product_tabs');

$tabs = trim( ob_get_clean() );

if ( ! empty( $tabs ) ) : ?>
	<div class="product-tab">
            <div class="row-fluid">
              <div class="container">
		 <div class="span3">
                  <ul class="nav-tabs nav product-tab product-tab-nav" id="myTab2">

			<?php echo $tabs; ?>
		</ul>
        </div>
		<?php do_action('woocommerce_product_tab_panels'); ?>
	</div>
    </div>
    </div>
<?php endif; ?>


