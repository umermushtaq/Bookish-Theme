<?php
/**
 * Simple product add to cart
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $woocommerce, $product, $posts;

if ( ! $product->is_purchasable() ) return;

// Availability
	$availability = $product->get_availability();
	
?>


			  <ul class="product-info">
              
              
              <?php if ( !empty ( $availability['availability'] ) ): ?>
                <li> <strong class="title">Availability: <span class="info">
                
              
              
<?php
	

	if ($availability['availability']) :
		echo apply_filters( 'woocommerce_stock_html',  esc_html( $availability['availability'] ) , $availability['availability'] );
    endif;
?>
			</span></strong> </li>
            
            <?php endif; ?>			
			<li> <strong class="title">Category: <span class="info"><?php echo $product->get_categories( ', ', '' . _n( '', '', sizeof( get_the_terms( $post->ID, 'product_cat' ) ), 'woocommerce' ) . ' ', '.' ); ?></span></strong> </li>
              </ul>
              

<?php if ( $product->is_in_stock() ) : ?>

	<?php do_action('woocommerce_before_add_to_cart_form'); ?>
	
	<form action="<?php echo esc_url( $product->add_to_cart_url() ); ?>" class="cart" method="post" enctype='multipart/form-data' style="width:50%;">

	 	<?php do_action('woocommerce_before_add_to_cart_button'); ?>

	 	<?php
	 		if ( ! $product->is_sold_individually() )
	 			woocommerce_quantity_input( array(
	 				'min_value' => apply_filters( 'woocommerce_quantity_input_min', 1, $product ),
	 				'max_value' => apply_filters( 'woocommerce_quantity_input_max', $product->backorders_allowed() ? '' : $product->get_stock_quantity(), $product )
	 			) );
	 	?>

	 	<button type="submit" class="single_add_to_cart_button button alt"><?php echo apply_filters('single_add_to_cart_text', __( 'Add to cart', 'woocommerce' ), $product->product_type); ?></button>

	 	<?php do_action('woocommerce_after_add_to_cart_button'); ?>

	</form>
	
	<?php do_action('woocommerce_after_add_to_cart_form'); ?>

<?php endif; ?>