<?php
/**
 * Description tab
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>


							<div class="span9">
                              <div class="tab-content">
                                <div class="tab-pane active" id="tab-description">
                                  <div class="tab-content-area">
                                  
                                  
                                  <?php 
										global $woocommerce, $post;
										$heading = esc_html( apply_filters('woocommerce_product_description_heading', __( 'Product Description', 'woocommerce' ) ) );
								  ?>
								  <?php the_content(); ?>
                                  
                                  
                                   </div>
                    			</div>
                              