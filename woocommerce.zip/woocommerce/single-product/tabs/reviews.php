<?php
/**
 * Reviews tab
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

 if ( comments_open() ) : ?>
 
                            
                                <div class="tab-pane active" id="tab-reviews">
                                  <div class="tab-content-area">
                                  
                                  <?php comments_template(); ?>
                                  
                                  </div>
                    			</div>
                              </div>
                            </div>
                            
<?php endif; ?>